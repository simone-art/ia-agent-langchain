/*
 * Copyright 2008-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.data.repository.core.support;

import org.springframework.aop.framework.ProxyFactory;
import org.springframework.data.repository.core.RepositoryInformation;

/**
 * Callback interface used during repository proxy creation. Allows manipulating the {@link ProxyFactory} creating the
 * repository.
 *
 * @author Oliver Gierke
 */
public interface RepositoryProxyPostProcessor {

	/**
	 * Manipulates the {@link ProxyFactory}, e.g. add further interceptors to it.
	 *
	 * @param factory will never be {@literal null}.
	 * @param repositoryInformation will never be {@literal null}.
	 */
	void postProcess(ProxyFactory factory, RepositoryInformation repositoryInformation);
}
