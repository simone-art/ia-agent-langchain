/*
 * Copyright 2012-2026 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.assertj.core.error;

import java.util.Iterator;

/**
 * Creates an error message indicating that an assertion that verifies that an {@link Iterator} has a next element
 * failed.
 * 
 * @author Stephan Windmüller
 */
public class ShouldHaveNext extends BasicErrorMessageFactory {

  private static final String SHOULD_HAVE_NEXT = "%nExpecting the iterator under test to contain another value but did not.";

  /**
   * Creates a new <code>{@link ShouldHaveNext}</code>.
   *
   * @return the created {@code ErrorMessageFactory}.
   */
  public static ErrorMessageFactory shouldHaveNext() {
    return new ShouldHaveNext();
  }

  private ShouldHaveNext() {
    super(SHOULD_HAVE_NEXT);
  }

}
