/*
 * Copyright 2012-2026 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.assertj.core.api;

/**
 * Assertion methods for {@code CharSequence}s.
 * <p>
 * To create a new instance of this class, invoke <code>{@link Assertions#assertThat(CharSequence)}</code>.
 * </p>
 * 
 * @author Mikhail Mazursky
 */
public class CharSequenceAssert extends AbstractCharSequenceAssert<CharSequenceAssert, CharSequence> {

  public static AbstractCharSequenceAssert<?, ? extends CharSequence> assertThatCharSequence(CharSequence actual) {
    return new CharSequenceAssert(actual);
  }

  public CharSequenceAssert(CharSequence actual) {
    super(actual, CharSequenceAssert.class);
  }
}
