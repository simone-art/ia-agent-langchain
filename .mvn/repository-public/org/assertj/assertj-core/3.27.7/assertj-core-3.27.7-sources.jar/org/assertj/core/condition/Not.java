/*
 * Copyright 2012-2026 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.assertj.core.condition;

import org.assertj.core.api.Condition;

/**
 * Returns {@code true} if the condition is not satisfied.
 * 
 * @author Nicolas François
 * @author Mikhail Mazursky
 */
public class Not<T> extends Negative<T> {

  /**
   * Creates a new <code>{@link Not}</code>.
   * 
   * @param <T> the type of value the {@link Condition} applies to.
   * @param condition the condition to inverse.
   * @return The Not condition created.
   */
  public static <T> Not<T> not(Condition<? super T> condition) {
    return new Not<>(condition);
  }

  private Not(Condition<? super T> condition) {
    super(condition);
    describedAs("not :<%s>", condition);
  }
}
