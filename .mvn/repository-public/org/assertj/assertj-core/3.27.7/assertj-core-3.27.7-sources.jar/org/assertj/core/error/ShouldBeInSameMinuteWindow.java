/*
 * Copyright 2012-2026 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.assertj.core.error;

import static org.assertj.core.util.DateUtil.formatTimeDifference;

import java.util.Date;

/**
 * Creates an error message indicating that an assertion that verifies that a {@link Date} is in minute window as
 * another one failed.
 *
 * @author Joel Costigliola
 */
public class ShouldBeInSameMinuteWindow extends BasicErrorMessageFactory {

  /**
   * Creates a new <code>{@link ShouldBeInSameMinuteWindow}</code>.
   *
   * @param actual the actual value in the failed assertion.
   * @param other  the value used in the failed assertion to compare the actual value to.
   * @return the created {@code ErrorMessageFactory}.
   */
  public static ErrorMessageFactory shouldBeInSameMinuteWindow(Date actual, Date other) {
    return new ShouldBeInSameMinuteWindow(actual, other);
  }

  private ShouldBeInSameMinuteWindow(Date actual, Date other) {
    super("%nExpecting actual:%n  %s%nto be close to:%n  %s%nby less than one minute (strictly) but difference was: "
          + formatTimeDifference(actual, other), actual, other);
  }
}
